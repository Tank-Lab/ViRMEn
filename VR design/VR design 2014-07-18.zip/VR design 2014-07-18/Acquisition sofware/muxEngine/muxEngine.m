function muxEngine(varargin)

if nargin == 1
    exper = eval(varargin{1});
else
    exper = mux64Signals;
end

global cf
cf = [];

cf.prop = exper.defaultProperties();
cf.p = convertStringStruct(cf.prop,'name','abbreviation');
cf.isEditing = false;
cf.running = true;
cf.exper = exper;
cf.coords = [];
cf.colors = [];
cf.numSamp = 0;
cf.currentTime = 0;
cf.numPix = 0;
cf.needResizing = true;
cf.needKeyboard = true;
cf.currentKey = '';
cf.option = '';
cf.selected = [];
cf.chooseTrigger = false;
cf.chooseSound = false;
cf.triggerCoords = [];
cf.triggerIndx = [];
cf.triggerTime = now;
cf.textString = {};
cf.backupStart = 1;
cf.backupNum = 1;
cf.triggerShowXTime = now;
cf.triggerShowYTime = now;
cf.yPositions = [];
cf.tickHeight = 0;
cf.tickWidth = 0;
cf.x = [];
cf.y = [];

[letterGrid letterFont] = muxLoadFont;

mfile = mfilename('fullpath');
path = fileparts(mfile);
NET.addAssembly([path filesep 'OpenTK.dll']);
NET.addAssembly([path filesep 'OpenTK.GLControl.dll']);
import  OpenTK.Graphics.OpenGL.*;

% Load .NET assemblies for using Windows system forms
NET.addAssembly('System');
NET.addAssembly('System.Windows.Forms');

cf.window = System.Windows.Forms.Form;
cf.window.Visible = true;
cf.window.Left = cf.p.windowPosition(1);
cf.window.Top = cf.p.windowPosition(2);
cf.window.Width = cf.p.windowPosition(3);
cf.window.Height = cf.p.windowPosition(4);
cf.oldPosition = cf.p.windowPosition;

% Start an OpenGL control and assign it to the Windows system form
cf.oglControl = OpenTK.GLControl;
cf.window.Controls.Add(cf.oglControl);

% Initialize OpenGL properties
GL.Ortho(-1,2,-1,1,-1e3,0);
GL.ClearColor(0,0,0,0);

% Enable the use of arrays to specify coordinates and colors
GL.EnableClientState(EnableCap.VertexArray);
GL.EnableClientState(EnableCap.ColorArray);

addlistener(cf.window,'ClientSizeChanged',@resizeWindow);
addlistener(cf.window,'Move',@resizeWindow);
addlistener(cf.window,'KeyPress',@keyPress);
addlistener(cf.window,'MouseEnter',@mouseEnter);
addlistener(cf.oglControl,'KeyPress',@keyPress);
addlistener(cf.oglControl,'MouseClick',@mouseClick);
addlistener(cf.oglControl,'MouseEnter',@mouseEnter);

cf = cf.exper.initializationFunction(cf);
drawnow

cf.window.Activate;

% Start sound
cf.ao = analogoutput('winsound');
addchannel(cf.ao,1:2);

cf.oldSamp = 0;
cf.startTime = now;
while 1
    drawnow
    
    % Obtain signals
    cf = cf.exper.runtimeFunction(cf);
    cf.option = '';
    
    if ~all(cf.oldPosition == cf.p.windowPosition)
        cf.window.Left = cf.p.windowPosition(1);
        cf.window.Top = cf.p.windowPosition(2);
        cf.window.Width = cf.p.windowPosition(3);
        cf.window.Height = cf.p.windowPosition(4);
        cf.needResizing = true;
    end
    
    if cf.needResizing
        cf.p.windowPosition = [cf.window.Left cf.window.Top cf.window.Width cf.window.Height];
        cf.oldPosition = cf.p.windowPosition;
        
        cf.oglControl.SetBounds(int32(10),int32(10),int32(cf.window.Width - 35),int32(cf.window.Height - 55));
        GL.Viewport(-(cf.window.Width - 35)+3*cf.p.margin,0,(cf.window.Width - 35)*3-6*cf.p.margin,cf.window.Height - 55);
        cf.numPix = double(cf.oglControl.Size.Width);
        cf.coords = [];
        
        % Grid
        cf.tickHeight = 2*5/double(cf.window.Height - 55);
        cf.tickWidth = 5/double(cf.window.Width - 35);
        cf.gridCoords = [zeros(1,9); -.8:.2:.8; cf.tickWidth*ones(1,9); -.8:.2:.8];
        cf.gridCoords = [cf.gridCoords [ones(1,9); -.8:.2:.8; 1-cf.tickWidth*ones(1,9); -.8:.2:.8]];
        cf.gridCoords = [cf.gridCoords [.1:.1:.9; ones(1,9); .1:.1:.9; 1-cf.tickHeight*ones(1,9)]];
        cf.gridCoords = [cf.gridCoords [.1:.1:.9; -ones(1,9); .1:.1:.9; cf.tickHeight*ones(1,9)-1]];
        cf.gridCoords = [cf.gridCoords [0 1; -1 -1; 0 1; 1 1]];
        cf.gridColors = ones(6,size(cf.gridCoords,2));
        cf.gridIndices = int32(0:2*size(cf.gridCoords,2)-1);
        cf.memGV = muxMemoryAddress(cf.gridCoords);
        cf.memGC = muxMemoryAddress(cf.gridColors);
        cf.memGI = muxMemoryAddress(cf.gridIndices);
        
        cf.gridHCoords = [zeros(1,9); -.8:.2:.8; ones(1,9); -.8:.2:.8];
        cf.gridHColors = 0.5*ones(6,size(cf.gridHCoords,2));
        cf.gridHIndices = int32(0:2*size(cf.gridHCoords,2)-1);
        cf.memHV = muxMemoryAddress(cf.gridHCoords);
        cf.memHC = muxMemoryAddress(cf.gridHColors);
        cf.memHI = muxMemoryAddress(cf.gridHIndices);
        
        cf.gridVCoords = [.1:.1:.9; -ones(1,9); .1:.1:.9; ones(1,9)];
        cf.gridVColors = 0.5*ones(6,size(cf.gridVCoords,2));
        cf.gridVIndices = int32(0:2*size(cf.gridVCoords,2)-1);
        cf.memVV = muxMemoryAddress(cf.gridVCoords);
        cf.memVC = muxMemoryAddress(cf.gridVColors);
        cf.memVI = muxMemoryAddress(cf.gridVIndices);
        
        cf.textSize = 8./[double(cf.window.Width - 35) double(cf.window.Height - 55)/2];
        cf.letterOffset = 8/double(cf.window.Width - 35);
    end
    cf.needResizing = false;
    if cf.needKeyboard
        keyProcess;
    end
    cf.needKeyboard = false;
    
    % Update window title
    if cf.p.xScale >= 10
        str = [num2str(cf.p.xScale/10) ' s'];
    else
        str = [num2str(cf.p.xScale*100) ' ms'];
    end
    cf.window.Text = [str ', ' datestr(now-cf.startTime,'HH:MM:SS')];
    
    % Play sound
    if cf.p.soundOn
        if strcmp(get(cf.ao,'Running'),'Off')
            set(cf.ao,'samplerate',cf.fs);
            putdata(cf.ao,cf.signals(:,[cf.p.soundSource cf.p.soundSource]));
            if get(cf.ao,'samplesavailable') > cf.p.soundBuffering*cf.fs
                start(cf.ao);
            end
        else
            putdata(cf.ao,cf.signals(:,[cf.p.soundSource cf.p.soundSource]));
        end
    elseif strcmp(get(cf.ao,'Running'),'On')
        stop(cf.ao);
    end
    
       
    % Filter signals
    signalSources = zeros(1,size(cf.p.configurations(cf.p.currentConfiguration).signalSources,2));
    for ndx = 1:length(signalSources)
        signalSources(ndx) = cf.p.configurations(cf.p.currentConfiguration).signalSources(cf.p.configurations(cf.p.currentConfiguration).sourceIndices(ndx),ndx);
    end
    cf.signals = cf.signals(:,signalSources);
    [unq, i, j] = unique(cf.p.configurations(cf.p.currentConfiguration).filters(cf.p.configurations(cf.p.currentConfiguration).filterGroups));
    lst = cell(1,length(unq));
    a = cell(1,length(unq));
    b = cell(1,length(unq));
    for ndx = 1:length(lst)
        lst{ndx} = find(j==ndx);
        a{ndx} = cf.p.filters(cf.p.configurations(cf.p.currentConfiguration).filters(cf.p.configurations(cf.p.currentConfiguration).filterGroups(i(ndx)))).a;
        b{ndx} = cf.p.filters(cf.p.configurations(cf.p.currentConfiguration).filters(cf.p.configurations(cf.p.currentConfiguration).filterGroups(i(ndx)))).b;
    end
    
    if ~iscell(cf.x) || length(cf.x) ~= length(lst)
        cf.x = cell(1,length(lst));
        cf.y = cell(1,length(lst));
    end
    
    for ndx = 1:length(lst)
        if ~all(size(cf.x{ndx})==[length(b{ndx})-1,length(lst{ndx})])
            cf.x{ndx} = zeros(length(b{ndx})-1,length(lst{ndx}));
            cf.y{ndx} = zeros(length(b{ndx})-1,length(lst{ndx}));
        end
        
        if ~isempty(b{ndx}) && ~isempty(a{ndx})
            xndx = cf.x{ndx};
            yndx = cf.y{ndx};
            cf.signals(:,lst{ndx}) = IIRFilterMex(b{ndx},a{ndx},cf.signals(:,lst{ndx}),yndx,xndx);
            cf.x{ndx} = xndx;
            cf.y{ndx} = yndx;
        end
    end

    cf.totNumSig = cf.p.channelsPerPage+length(cf.p.configurations(cf.p.currentConfiguration).headerChannels)+length(cf.p.configurations(cf.p.currentConfiguration).footerChannels);
    
    if cf.totNumSig == 0
        GL.Clear(ClearBufferMask.ColorBufferBit);
        try
            if cf.running
                cf.oglControl.SwapBuffers;
            end
        catch %#ok<CTCH>
            cf = cf.exper.terminationFunction(cf);
            return
        end
        continue
    end
    
    yoff = 2*cf.p.configurations(cf.p.currentConfiguration).yOffsets / (cf.totNumSig+1);
    
    browsableChannels = cell2mat(cf.p.configurations(cf.p.currentConfiguration).browsableChannels);
    indx = mod(cf.p.firstChannel:cf.p.firstChannel+cf.p.channelsPerPage-1,length(browsableChannels));
    indx(indx==0) = length(browsableChannels);
    chanLst = [cf.p.configurations(cf.p.currentConfiguration).headerChannels ...
        browsableChannels(indx) ...
        cf.p.configurations(cf.p.currentConfiguration).footerChannels];
    chanLst(chanLst>size(cf.signals,2)) = chanLst(chanLst>size(cf.signals,2))-size(cf.signals,2);
    
    
    if length(cf.textString) ~= size(cf.signals,2)
        cf.textString = cell(1,size(cf.signals,2));
        for ndx = 1:size(cf.signals,2)
            if cf.p.configurations(cf.p.currentConfiguration).yScales(ndx)/10 < 1
                cf.textString{ndx}{1} = [cf.p.filters(cf.p.configurations(cf.p.currentConfiguration).filters(cf.p.configurations(cf.p.currentConfiguration).filterGroups(ndx))).abbreviation ...
                    cf.p.signalNames{signalSources(ndx)}];
                cf.textString{ndx}{2} = [num2str(cf.p.configurations(cf.p.currentConfiguration).yScales(ndx)*100) 'mV'];
            else
                cf.textString{ndx}{1} = [cf.p.filters(cf.p.configurations(cf.p.currentConfiguration).filters(cf.p.configurations(cf.p.currentConfiguration).filterGroups(ndx))).abbreviation ...
                    cf.p.signalNames{signalSources(ndx)}];
                cf.textString{ndx}{2} = [num2str(cf.p.configurations(cf.p.currentConfiguration).yScales(ndx)/10) 'V'];
            end
            if cf.p.soundOn && cf.p.soundSource == ndx
                cf.textString{ndx}{1} = ['S ' cf.textString{ndx}{1}];
            end
        end
    end
    
    deltaSamp = cf.numSamp - cf.oldSamp;
    cf.oldSamp = cf.numSamp;
        
    if size(cf.coords,1) ~= 4*cf.totNumSig
        cf.numPix = double(cf.oglControl.Size.Width);
        xs = linspace(0,1,cf.numPix+1);
        xs = xs(1:end-1)+diff(xs)/2;
        coords = [xs; inf(1,cf.numPix); xs; -inf(1,cf.numPix)];
        cf.coords = repmat(coords,cf.totNumSig,1);
        cf.triggerCoords = repmat(coords,cf.totNumSig,1);
        cf.colors = ones(6*cf.totNumSig,cf.numPix);
        cf.indices = int32(0:2*cf.totNumSig*cf.numPix-1);
        nindx = [0:2:2*cf.totNumSig*cf.numPix-1-2*cf.totNumSig; ...
            (0:2:2*cf.totNumSig*cf.numPix-1-2*cf.totNumSig)+2*cf.totNumSig+1];
        cf.indices = [cf.indices int32(nindx(:)')];
        cf.yPositions = (1-2/(cf.totNumSig+1)):-2/(cf.totNumSig+1):(-1+2/(cf.totNumSig+1));
    end
    
    cf.currentTime = cf.numSamp/cf.rawFs;
    
    if cf.p.triggerOn
        if isempty(cf.triggerIndx) && (now-cf.triggerTime)*24*60*60 > cf.p.xScale
            if cf.p.triggerThreshold >= 0
                ftrig = find(cf.signals(:,cf.p.triggerSource) > cf.p.triggerThreshold, 1);
            else
                ftrig = find(cf.signals(:,cf.p.triggerSource) < cf.p.triggerThreshold, 1);
            end
            if ~isempty(ftrig)
                t = ftrig/cf.fs;
                t = round(t/cf.p.xScale*(cf.numPix-1)+cf.numPix);
                cf.triggerIndx = t;
                cf.triggerTime = now;
            end
        end
        
        deltaPix = round(deltaSamp/cf.rawFs/cf.p.xScale*(cf.numPix-1));
        arrSz = fix(deltaPix/(cf.numPix-1));
        deltaPixArr = (cf.numPix-1)*ones(1,arrSz);
        deltaPixArr = [deltaPix-sum(deltaPixArr) deltaPixArr]; %#ok<AGROW>
        
        tm = -(size(cf.signals,1)-1:-1:0)/cf.fs;
        tm = round(tm/cf.p.xScale*(cf.numPix-1));

        for ndx = 1:length(deltaPixArr)
            ft = fix(-tm/(cf.numPix-1)) == length(deltaPixArr)-ndx;
            t = tm(ft);
            if isempty(t)
                continue
            end
            t = t-t(end)+cf.numPix;
            if isempty(cf.triggerIndx) || cf.triggerIndx - deltaPixArr(ndx) > round(cf.p.triggerXPosition*size(cf.triggerCoords,2))
                % Roll
                cf.triggerCoords(2:2:end,:) = [cf.triggerCoords(2:2:end,deltaPixArr(ndx)+1:end) NaN(size(cf.triggerCoords,1)/2,deltaPixArr(ndx))];
                for ch = 1:cf.totNumSig
                    if t(end)<=size(cf.triggerCoords,2) && ch<=size(cf.signals,2)
                        updateMinMax(cf.triggerCoords,t,cf.signals(ft,chanLst(ch)),ch,2/cf.p.configurations(cf.p.currentConfiguration).yScales(chanLst(ch)),cf.yPositions(ch)+yoff(chanLst(ch)));
                    end
                end
                cf.triggerIndx = cf.triggerIndx - deltaPixArr(ndx);
            else
                cf.triggerIndx = cf.triggerIndx - deltaPixArr(ndx);
                bck = zeros(size(cf.triggerCoords,1),round(cf.p.triggerXPosition*size(cf.triggerCoords,2))-cf.triggerIndx);
                bck(2:2:end,:) = cf.triggerCoords(2:2:end,deltaPixArr(ndx)-size(bck,2):deltaPixArr(ndx)-1);
                cf.triggerCoords(2:2:end,:) = [cf.triggerCoords(2:2:end,deltaPixArr(ndx)+1:end) NaN(size(cf.triggerCoords,1)/2,deltaPixArr(ndx))];
                for ch = 1:cf.totNumSig
                    if t(end)<=size(cf.triggerCoords,2) && ch<=size(cf.signals,2)
                        updateMinMax(cf.triggerCoords,t,cf.signals(ft,chanLst(ch)),ch,2/cf.p.configurations(cf.p.currentConfiguration).yScales(chanLst(ch)),cf.yPositions(ch)+yoff(chanLst(ch)));
                    end
                end
                cf.coords(2:2:end,:) = cf.triggerCoords(2:2:end,:);
                cf.coords(2:2:end,:) = [bck(2:2:end,:) cf.triggerCoords(2:2:end,1:end-size(bck,2))];
                cf.triggerIndx = [];
            end
        end
    else
        if cf.p.xScale > .2 && ~cf.p.rollingMode
            t = cf.currentTime-(size(cf.signals,1)-1:-1:0)/cf.fs;
            t = round(mod(t,cf.p.xScale)/cf.p.xScale*(cf.numPix-1)+1);
        else
            deltaPix = round(deltaSamp/cf.rawFs/cf.p.xScale*(cf.numPix-1));
            cf.coords(2:2:end,:) = [cf.coords(2:2:end,deltaPix+1:end) zeros(size(cf.coords,1)/2,min(deltaPix,size(cf.coords,2)))];
            t = -(size(cf.signals,1)-1:-1:0)/cf.fs;
            t = round(t/cf.p.xScale*(cf.numPix-1)+cf.numPix);
        end
        
        for ch = 1:cf.totNumSig
            updateMinMax(cf.coords,t(t>0),cf.signals(t>0,chanLst(ch)),ch,2/cf.p.configurations(cf.p.currentConfiguration).yScales(chanLst(ch)),cf.yPositions(ch)+yoff(chanLst(ch)));
        end
        
        if cf.p.xScale > .2 && ~cf.p.rollingMode
            blst = min([t(end)+1 cf.numPix]):min([t(end)+cf.p.darkStripWidth cf.numPix]);
            cf.coords(2:4:end,blst) = inf;
            cf.coords(4:4:end,blst) = -inf;
        end
    end
    
    for ch = 1:cf.totNumSig
        cf.colors(6*(ch-1)+[1 4],:) = cf.p.colors(cf.p.configurations(cf.p.currentConfiguration).colors(cf.p.configurations(cf.p.currentConfiguration).colorGroups(chanLst(ch))),1);
        cf.colors(6*(ch-1)+[2 5],:) = cf.p.colors(cf.p.configurations(cf.p.currentConfiguration).colors(cf.p.configurations(cf.p.currentConfiguration).colorGroups(chanLst(ch))),2);
        cf.colors(6*(ch-1)+[3 6],:) = cf.p.colors(cf.p.configurations(cf.p.currentConfiguration).colors(cf.p.configurations(cf.p.currentConfiguration).colorGroups(chanLst(ch))),3);
    end
    
    GL.Clear(ClearBufferMask.ColorBufferBit);
    
    GL.Disable(EnableCap.LineStipple);
    
    if cf.p.showGridHorizontal
        GL.LineWidth(1);
        GL.ColorPointer(int32(3),ColorPointerType.Double,int32(0),cf.memHC);
        GL.VertexPointer(int32(2),VertexPointerType.Double,int32(0),cf.memHV);
        GL.DrawElements(BeginMode.Lines,int32(numel(cf.gridHIndices)),DrawElementsType.UnsignedInt,cf.memHI);
    end
    if cf.p.showGridVertical
        GL.LineWidth(1);
        GL.ColorPointer(int32(3),ColorPointerType.Double,int32(0),cf.memVC);
        GL.VertexPointer(int32(2),VertexPointerType.Double,int32(0),cf.memVV);
        GL.DrawElements(BeginMode.Lines,int32(numel(cf.gridHIndices)),DrawElementsType.UnsignedInt,cf.memVI);
    end
    
    memC = muxMemoryAddress(cf.colors);
    cf.memV = muxMemoryAddress(cf.coords);
    memI = muxMemoryAddress(cf.indices);
    GL.LineWidth(1);
    GL.ColorPointer(int32(3),ColorPointerType.Double,int32(0),memC);
    GL.VertexPointer(int32(2),VertexPointerType.Double,int32(0),cf.memV);
    GL.DrawElements(BeginMode.Lines,int32(numel(cf.indices)),DrawElementsType.UnsignedInt,memI);
    
    GL.LineWidth(2);
    GL.ColorPointer(int32(3),ColorPointerType.Double,int32(0),cf.memGC);
    GL.VertexPointer(int32(2),VertexPointerType.Double,int32(0),cf.memGV);
    GL.DrawElements(BeginMode.Lines,int32(numel(cf.gridIndices)),DrawElementsType.UnsignedInt,cf.memGI);
    
    try
        if cf.p.triggerOn
            f = find(chanLst==cf.p.triggerSource);
            if ~isempty(f)
                if (now-cf.triggerShowYTime)*24*60*60 < cf.p.showThresholdDuration
                    GL.Enable(EnableCap.LineStipple)
                    GL.LineStipple(1, 3855);
                    GL.LineWidth(1);
                    GL.Color3(1,1,1);
                    GL.Begin(BeginMode.Lines);
                    GL.Vertex2(0,cf.yPositions(f)+yoff(cf.p.triggerSource)+2/cf.p.configurations(cf.p.currentConfiguration).yScales(cf.p.triggerSource)*cf.p.triggerThreshold);
                    GL.Vertex2(1,cf.yPositions(f)+yoff(cf.p.triggerSource)+2/cf.p.configurations(cf.p.currentConfiguration).yScales(cf.p.triggerSource)*cf.p.triggerThreshold);
                    GL.End();
                else
                    GL.Disable(EnableCap.LineStipple)
                    GL.LineStipple(1, 3855);
                    GL.LineWidth(2);
                    GL.Color3(1,1,1);
                    GL.Begin(BeginMode.Lines);
                    GL.Vertex2(1,cf.yPositions(f)+yoff(cf.p.triggerSource)+2/cf.p.configurations(cf.p.currentConfiguration).yScales(cf.p.triggerSource)*cf.p.triggerThreshold);
                    GL.Vertex2(1-cf.tickWidth*3,cf.yPositions(f)+yoff(cf.p.triggerSource)+2/cf.p.configurations(cf.p.currentConfiguration).yScales(cf.p.triggerSource)*cf.p.triggerThreshold);
                    GL.End();
                end
            end
            if (now-cf.triggerShowXTime)*24*60*60 < cf.p.showTriggerDuration
                GL.Color3(cf.p.colors(cf.p.configurations(cf.p.currentConfiguration).colors(cf.p.configurations(cf.p.currentConfiguration).colorGroups(cf.p.triggerSource)),1),cf.p.colors(cf.p.configurations(cf.p.currentConfiguration).colors(cf.p.configurations(cf.p.currentConfiguration).colorGroups(cf.p.triggerSource)),2),cf.p.colors(cf.p.configurations(cf.p.currentConfiguration).colors(cf.p.configurations(cf.p.currentConfiguration).colorGroups(cf.p.triggerSource)),3));
                GL.Enable(EnableCap.LineStipple);
                GL.LineStipple(1, 3855);
                GL.LineWidth(1);
                GL.Begin(BeginMode.Lines);
                GL.Vertex2(cf.p.triggerXPosition,-1);
                GL.Vertex2(cf.p.triggerXPosition,1);
                GL.End();
            else
                GL.Color3(cf.p.colors(cf.p.configurations(cf.p.currentConfiguration).colors(cf.p.configurations(cf.p.currentConfiguration).colorGroups(cf.p.triggerSource)),1),cf.p.colors(cf.p.configurations(cf.p.currentConfiguration).colors(cf.p.configurations(cf.p.currentConfiguration).colorGroups(cf.p.triggerSource)),2),cf.p.colors(cf.p.configurations(cf.p.currentConfiguration).colors(cf.p.configurations(cf.p.currentConfiguration).colorGroups(cf.p.triggerSource)),3));
                GL.Disable(EnableCap.LineStipple);
                GL.LineWidth(2);
                GL.Begin(BeginMode.Lines);
                GL.Vertex2(cf.p.triggerXPosition,1);
                GL.Vertex2(cf.p.triggerXPosition,1-cf.tickHeight*3);
                GL.End();
            end
        end
    catch %#ok<CTCH>
        cf = cf.exper.terminationFunction(cf);
        return
    end
    
    cf.text = struct('string',{},'position',{},'size',{},'color',{});
    for ndx = 1:cf.totNumSig
        cf.text(2*ndx-1).string = cf.textString{chanLst(ndx)}{1};
        cf.text(2*ndx).string = cf.textString{chanLst(ndx)}{2};
        cf.text(2*ndx-1).size = cf.textSize;
        cf.text(2*ndx).size = cf.textSize;
        cf.text(2*ndx-1).position = [-cf.letterOffset-length(cf.textString{chanLst(ndx)}{1})*cf.text(2*ndx-1).size(1) cf.yPositions(ndx)+yoff(chanLst(ndx))+-cf.text(2*ndx-1).size(2)*0.6];
        cf.text(2*ndx).position = [1+cf.letterOffset cf.yPositions(ndx)+yoff(chanLst(ndx))+-cf.text(ndx).size(2)*0.6];
        if ~any(cf.selected==chanLst(ndx))
            cf.text(2*ndx-1).color = cf.p.colors(cf.p.configurations(cf.p.currentConfiguration).colors(cf.p.configurations(cf.p.currentConfiguration).colorGroups(chanLst(ndx))),:);
            cf.text(2*ndx).color = cf.p.colors(cf.p.configurations(cf.p.currentConfiguration).colors(cf.p.configurations(cf.p.currentConfiguration).colorGroups(chanLst(ndx))),:);
        else
            cf.text(2*ndx-1).color = [1 1 1];
            cf.text(2*ndx).color = [1 1 1];
        end
    end
    
    % Determine the total number of line segments to draw
    tot = 0;
    for ndx = 1:length(cf.text)
        for s = 1:length(cf.text(ndx).string)
            tot = tot+length(letterFont{double(cf.text(ndx).string(s))});
        end
    end
    colors = zeros(6,tot);
    coords = zeros(4,tot);
    
    % Create arrays of coordinates, colors and indices
    cnt = 0;
    for ndx = 1:length(cf.text)
        for s = 1:length(cf.text(ndx).string)
            createLetters(coords,colors,cnt,letterGrid,letterFont{double(cf.text(ndx).string(s))},cf.text(ndx).size,cf.text(ndx).position,s,cf.text(ndx).color);
        end
    end
    indices = int32(0:2*size(coords,2)-1);
    
    % Obtain memory pointers for use by OpenGL
    memC = virmenMemoryAddress(colors);
    cf.memV = virmenMemoryAddress(coords);
    memI = virmenMemoryAddress(indices);
    
    % Setup pointers to vertex and color arrays for the line segments
    GL.ColorPointer(int32(3),ColorPointerType.Double,int32(0),memC);
    GL.VertexPointer(int32(2),VertexPointerType.Double,int32(0),cf.memV);
    
    % Draw line segments
    GL.Disable(EnableCap.LineStipple);
    GL.LineWidth(2);
    GL.DrawElements(BeginMode.Lines,int32(numel(indices)),DrawElementsType.UnsignedInt,memI);
    
    try
        if cf.running
            cf.oglControl.SwapBuffers;
        end
    catch %#ok<CTCH>
        cf = cf.exper.terminationFunction(cf);
        return
    end
end



function mouseClick(~,evt)

global cf
y = 1-2*(double(evt.Y)/double(cf.oglControl.Height));

yoff = 2*cf.p.configurations(cf.p.currentConfiguration).yOffsets / (cf.totNumSig+1);

browsableChannels = cell2mat(cf.p.configurations(cf.p.currentConfiguration).browsableChannels);
groupIndx = [];
for ndx = 1:length(cf.p.configurations(cf.p.currentConfiguration).browsableChannels)
    groupIndx = [groupIndx ndx*ones(1,length(cf.p.configurations(cf.p.currentConfiguration).browsableChannels{ndx}))]; %#ok<AGROW>
end
indx = mod(cf.p.firstChannel:cf.p.firstChannel+cf.p.channelsPerPage-1,length(browsableChannels));
indx(indx==0) = length(browsableChannels);
lst = [cf.p.configurations(cf.p.currentConfiguration).headerChannels ...
    browsableChannels(indx) ...
    cf.p.configurations(cf.p.currentConfiguration).footerChannels];
if isempty(lst)
    return
end
lstGroup = [zeros(1,length(cf.p.configurations(cf.p.currentConfiguration).headerChannels)) ...
    groupIndx zeros(1,length(cf.p.configurations(cf.p.currentConfiguration).footerChannels))];
[~, indx] = min(abs(y-cf.yPositions-yoff(lst)));

if cf.chooseTrigger
    cf.p.triggerSource = lst(indx(1));
    cf.p.triggerThreshold = (y-cf.yPositions(indx(1))-yoff(cf.p.triggerSource))*cf.p.configurations(cf.p.currentConfiguration).yScales(lst(indx(1)))/2;
    cf.chooseTrigger = false;
    cf.p.triggerOn = true;
    cf.triggerShowYTime = now;
elseif cf.chooseSound
    cf.p.soundSource = lst(indx(1));
    cf.chooseSound = false;
    cf.p.soundOn = true;
    cf.textString = {};
else
    backupSel = cf.selected;
    b = evt.Button.ToString.Chars(int32(0));
    if strcmp(b,'R') || indx(1)<=length(cf.p.configurations(cf.p.currentConfiguration).headerChannels) || indx(1)>length(cf.p.configurations(cf.p.currentConfiguration).headerChannels)+cf.p.channelsPerPage
        cf.selected = indx(1);
        cf.selected = lst(cf.selected);
    else
        cf.selected = lst(lstGroup==lstGroup(indx(1)));
    end
    if length(backupSel)==length(cf.selected) && all(backupSel==cf.selected)
        cf.selected = [];
    end
end

function resizeWindow(~,~)

global cf
cf.needResizing = true;

function keyPress(~,evt)

global cf
cf.currentKey = evt.KeyChar;
cf.needKeyboard = true;


function keyProcess

global cf


groups = [];
for ndx = 1:length(cf.p.configurations(cf.p.currentConfiguration).browsableChannels)
    groups = [groups ndx*ones(1,length(cf.p.configurations(cf.p.currentConfiguration).browsableChannels{ndx}))]; %#ok<AGROW>
end

sameFilter = [];
for ndx = 1:length(cf.selected)
    sameFilter = [sameFilter find(cf.p.configurations(cf.p.currentConfiguration).filterGroups==cf.p.configurations(cf.p.currentConfiguration).filterGroups(cf.selected(ndx)))]; %#ok<AGROW>
end
sameFilter = unique(sameFilter);
if isempty(sameFilter)
    sameFilter = 1:length(cf.p.configurations(cf.p.currentConfiguration).filterGroups);
end

browsableChannels = cell2mat(cf.p.configurations(cf.p.currentConfiguration).browsableChannels);
signalSources = zeros(1,size(cf.p.configurations(cf.p.currentConfiguration).signalSources,2));
for ndx = 1:length(signalSources)
    signalSources(ndx) = cf.p.configurations(cf.p.currentConfiguration).signalSources(cf.p.configurations(cf.p.currentConfiguration).sourceIndices(ndx),ndx);
end

switch cf.currentKey
    case ','
        oom = floor(log10(cf.p.xScale));
        val = cf.p.xScale/10^oom;
        if val < 2
            cf.p.xScale = 2*10^oom;
        elseif val < 5
            cf.p.xScale = 5*10^oom;
        else
            cf.p.xScale = 10*10^oom;
        end
        cf.coords = [];
    case '.'
        oom = floor(log10(cf.p.xScale));
        val = cf.p.xScale/10^oom;
        if val > 5
            cf.p.xScale = 5*10^oom;
        elseif val > 2
            cf.p.xScale = 2*10^oom;
        elseif val > 1
            cf.p.xScale = 1*10^oom;
        else
            cf.p.xScale = 5*10^(oom-1);
        end
        cf.coords = [];
    case 'r'
        cf.p.rollingMode = ~cf.p.rollingMode;
        cf.coords = [];
    case 'U'
        if isempty(browsableChannels)
            return
        end
        if cf.p.channelsPerPage > 0
            fc = find(mod(length(browsableChannels),1:length(browsableChannels))==0);
            f = find(fc==cf.p.channelsPerPage);
            if f < length(fc)
                f = f+1;
            end
            cf.p.channelsPerPage = fc(f);
        else
            cf.p.channelsPerPage = 1;
        end
        cf.p.firstChannel = fix((cf.p.firstChannel-1)/cf.p.channelsPerPage)*cf.p.channelsPerPage+1;
        cf.coords = [];
    case 'u'
        if isempty(browsableChannels)
            return
        end
        fc = find(mod(length(browsableChannels),1:length(browsableChannels))==0);
        f = find(fc==cf.p.channelsPerPage);
        if f > 1
            f = f-1;
            cf.p.channelsPerPage = fc(f);
            cf.p.firstChannel = fix((cf.p.firstChannel-1)/cf.p.channelsPerPage)*cf.p.channelsPerPage+1;
        else
            cf.p.channelsPerPage = 0;
            cf.p.firstChannel = 1;
        end
        cf.coords = [];
    case '{'
        grp = groups(cf.p.firstChannel);
        grp = grp-1;
        if grp == 0
            grp = max(groups);
        end
        num = length(find(groups==grp));
        cf.p.firstChannel = cf.p.firstChannel - num;
        if cf.p.firstChannel < 1
            cf.p.firstChannel = length(browsableChannels)+cf.p.firstChannel;
        end
    case '}'
        grp = groups(cf.p.firstChannel);
        num = length(find(groups==grp));
        cf.p.firstChannel = cf.p.firstChannel + num;
        if cf.p.firstChannel > length(browsableChannels)
            cf.p.firstChannel = cf.p.firstChannel - length(browsableChannels);
        end
    case '['
        cf.p.firstChannel = cf.p.firstChannel - cf.p.channelsPerPage;
        if cf.p.firstChannel < 1
            cf.p.firstChannel = length(browsableChannels)+cf.p.firstChannel;
        end
    case ']'
        cf.p.firstChannel = cf.p.firstChannel + cf.p.channelsPerPage;
        if cf.p.firstChannel > length(browsableChannels)
            cf.p.firstChannel = cf.p.firstChannel - length(browsableChannels);
        end
    case {'=','+'}
        if strcmp(cf.currentKey,'+')
            sel = sameFilter;
        else
            sel = cf.selected;
        end
        for ndx = 1:length(sel)
            ys = cf.p.configurations(cf.p.currentConfiguration).yScales(sel(ndx));
            oom = floor(log10(ys));
            val = ys/10^oom;
            if val > 5
                ys = 5*10^oom;
            elseif val > 2
                ys = 2*10^oom;
            elseif val > 1
                ys = 1*10^oom;
            else
                ys = 5*10^(oom-1);
            end
            cf.p.configurations(cf.p.currentConfiguration).yScales(sel(ndx)) = ys;
        end
        cf.textString = {};
    case {'-','_'}
        if strcmp(cf.currentKey,'_')
            sel = sameFilter;
        else
            sel = cf.selected;
        end
        for ndx = 1:length(sel)
            ys = cf.p.configurations(cf.p.currentConfiguration).yScales(sel(ndx));
            oom = floor(log10(ys));
            val = ys/10^oom;
            if val < 2
                ys = 2*10^oom;
            elseif val < 5
                ys = 5*10^oom;
            else
                ys = 10*10^oom;
            end
            cf.p.configurations(cf.p.currentConfiguration).yScales(sel(ndx)) = ys;
        end
        cf.textString = {};
    case char(8)
        for ndx = 1:length(cf.selected)
            sf = find(cf.p.configurations(cf.p.currentConfiguration).filterGroups==cf.p.configurations(cf.p.currentConfiguration).filterGroups(cf.selected(ndx)));
            md = mode(cf.p.configurations(cf.p.currentConfiguration).yScales(sf));
            cf.p.configurations(cf.p.currentConfiguration).yScales(sf) = md;
        end
        cf.textString = {};
    case '"'
        if isempty(cf.p.configurations(cf.p.currentConfiguration).yScales)
            return
        end
        cf.p.triggerThreshold = cf.p.triggerThreshold + .005*cf.p.configurations(cf.p.currentConfiguration).yScales(cf.p.triggerSource)/2;
        cf.triggerShowYTime = now;
    case ':'
        if isempty(cf.p.configurations(cf.p.currentConfiguration).yScales)
            return
        end
        cf.p.triggerThreshold = cf.p.triggerThreshold - .005*cf.p.configurations(cf.p.currentConfiguration).yScales(cf.p.triggerSource)/2;
        cf.triggerShowYTime = now;
    case ''''
        if isempty(cf.p.configurations(cf.p.currentConfiguration).yScales)
            return
        end
        cf.p.triggerThreshold = cf.p.triggerThreshold + .05*cf.p.configurations(cf.p.currentConfiguration).yScales(cf.p.triggerSource)/2;
        cf.triggerShowYTime = now;
    case ';'
        if isempty(cf.p.configurations(cf.p.currentConfiguration).yScales)
            return
        end
        cf.p.triggerThreshold = cf.p.triggerThreshold - .05*cf.p.configurations(cf.p.currentConfiguration).yScales(cf.p.triggerSource)/2;
        cf.triggerShowYTime = now;
    case '>'
        cf.p.triggerXPosition = cf.p.triggerXPosition + .01;
        if cf.p.triggerXPosition > 1
            cf.p.triggerXPosition = 1;
        end
        cf.triggerShowXTime = now;
    case '<'
        cf.p.triggerXPosition = cf.p.triggerXPosition - .01;
        if cf.p.triggerXPosition < 0
            cf.p.triggerXPosition = 0;
        end
        cf.triggerShowXTime = now;
    case 'l'
        cf.chooseTrigger = ~cf.chooseTrigger;
    case 'L'
        cf.p.triggerOn = ~cf.p.triggerOn;
        cf.triggerShowYTime = now;
        cf.chooseTrigger = false;
    case 's'
        cf.chooseSound = ~cf.chooseSound;
        cf.textString = {};
    case 'S'
        cf.p.soundOn = ~cf.p.soundOn;
        cf.chooseSound = false;
        cf.textString = {};
    case char(13)
        if ~isempty(cf.selected) && cf.selected(1) <= length(browsableChannels)
            if cf.p.firstChannel == cf.selected(1) && cf.p.channelsPerPage == length(cf.selected)
                cf.p.firstChannel = cf.backupStart;
                cf.p.channelsPerPage = cf.backupNum;
            else
                cf.backupStart = cf.p.firstChannel;
                cf.backupNum = cf.p.channelsPerPage;
                cf.p.firstChannel = cf.selected(1);
                cf.p.channelsPerPage = length(cf.selected);
            end
        end
        cf.chooseTrigger = false;
    case 'G'
        cf.p.showGridHorizontal = ~cf.p.showGridHorizontal;
    case 'g'
        cf.p.showGridVertical = ~cf.p.showGridVertical;
    case {'0',')'}
        if strcmp(cf.currentKey,')')
            sel = sameFilter;
        else
            sel = cf.selected;
        end
        cf.p.configurations(cf.p.currentConfiguration).yOffsets(sel) = cf.p.configurations(cf.p.currentConfiguration).yOffsets(sel)+.05;
        cf.p.configurations(cf.p.currentConfiguration).yOffsets(cf.p.configurations(cf.p.currentConfiguration).yOffsets>1) = 1;
    case {'9','('}
        if strcmp(cf.currentKey,'(')
            sel = sameFilter;
        else
            sel = cf.selected;
        end
        cf.p.configurations(cf.p.currentConfiguration).yOffsets(sel) = cf.p.configurations(cf.p.currentConfiguration).yOffsets(sel)-.05;
        cf.p.configurations(cf.p.currentConfiguration).yOffsets(cf.p.configurations(cf.p.currentConfiguration).yOffsets<-1) = -1;
    case {'o','O'}
        if strcmp(cf.currentKey,'O')
            sel = sameFilter;
        else
            sel = cf.selected;
        end
        cf.p.configurations(cf.p.currentConfiguration).yOffsets(sel) = 0;
    case {'p','P'}
        cf.running = ~cf.running;
    case char(9)
%         indx = mod(cf.p.firstChannel:cf.p.firstChannel+cf.p.channelsPerPage-1,length(browsableChannels));
%         indx(indx==0) = length(browsableChannels);
%         oldList = browsableChannels(indx);
%         oldList = signalSources(oldList);
        
        cf.p.currentConfiguration = cf.p.currentConfiguration + 1;
        if cf.p.currentConfiguration > length(cf.p.configurations)
            cf.p.currentConfiguration = 1;
        end
%         browsableChannels = cell2mat(cf.p.configurations(cf.p.currentConfiguration).browsableChannels);
%         
%         indx = [];
%         for ndx = 1:length(browsableChannels)
%             if ~isempty(find(oldList==cf.p.configurations(cf.p.currentConfiguration).signalSources(browsableChannels(ndx)),1))
%                 indx(end+1) = ndx; %#ok<AGROW>
%             end
%         end
%         indx = min(indx):max(indx);
%         if isempty(indx)
%             cf.p.firstChannel = 1;
%             cf.p.channelsPerPage = 0;
%         else
%             cf.p.firstChannel = indx(1);
%             fc = find(mod(length(browsableChannels),1:length(browsableChannels))==0);
%             fc(fc < length(indx)) = [];
%             if isempty(fc)
%                 cf.p.channelsPerPage = length(browsableChannels);
%             else
%                 cf.p.channelsPerPage = fc(1);
%             end
%         end
        cf.textString = {};
        cf.selected = [];
    case {'\','|'}
        if strcmp(cf.currentKey,'|')
            sel = sameFilter;
        else
            sel = cf.selected;
        end
        cf.p.configurations(cf.p.currentConfiguration).sourceIndices(sel) = cf.p.configurations(cf.p.currentConfiguration).sourceIndices(sel)+1;
        cf.p.configurations(cf.p.currentConfiguration).sourceIndices(cf.p.configurations(cf.p.currentConfiguration).sourceIndices>size(cf.p.configurations(cf.p.currentConfiguration).signalSources,1)) = 1;
        cf.textString = {};
    otherwise
        cf.option = cf.currentKey;
end

cf.currentKey = '';

function mouseEnter(varargin)

global cf

cf.window.Activate;