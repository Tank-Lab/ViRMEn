function exper = mux64SignalsTest

exper.defaultProperties = @defaultPropertiesInThisFile;
exper.initializationFunction = @initializationInThisFile;
exper.runtimeFunction = @runtimeInThisFile;
exper.terminationFunction = @terminationInThisFile;

function prop = defaultPropertiesInThisFile

prop.xScale = 1;
prop.rollingMode = false;
prop.darkStripWidth = 10;
prop.margin = 70;
prop.showGridHorizontal = false;
prop.showGridVertical = true;
prop.channelsPerPage = 0;
prop.firstChannel = 1;
prop.triggerOn = false;
prop.triggerSource = 1;
prop.triggerThreshold = 1.9;
prop.triggerXPosition = 0.5;
prop.showThresholdDuration = 2;
prop.showTriggerDuration = 2;
prop.windowPosition = [100 100 400 600];
prop.currentConfiguration = 1;
prop.soundSource = 1;
prop.soundBuffering = 0.07;
prop.soundOn = false;

h  = fdesign.highpass('N,F3dB', 1, 500, 31250);
Hd = design(h, 'butter');
[b{1},a{1}] = sos2tf(Hd.sosMatrix,Hd.ScaleValues);
h  = fdesign.bandpass('N,F3dB1,F3dB2', 6, 80, 250, 31250);
Hd = design(h, 'butter');
[b{2},a{2}] = sos2tf(Hd.sosMatrix,Hd.ScaleValues);
for j = 1:length(b)
    for ndx = length(b{j}):-1:1
        if b{j}(ndx)==0 && a{j}(ndx)==0
            b{j}(ndx) = [];
            a{j}(ndx) = [];
        else
            break
        end
    end
end

prop.filters(1).name = 'Unfiltered LFP';
prop.filters(1).abbreviation = 'LFP';
prop.filters(1).b = [];
prop.filters(1).a = [];
prop.filters(2).name = 'Spikes (>500 Hz)';
prop.filters(2).abbreviation = 'SPK';
prop.filters(2).b = b{1};
prop.filters(2).a = a{1};
prop.filters(3).name = 'Ripples (800-250 Hz)';
prop.filters(3).abbreviation = 'RPL';
prop.filters(3).b = b{2};
prop.filters(3).a = a{2};
prop.filters(4).name = 'Unfiltered & unlabeled';
prop.filters(4).abbreviation = '';
prop.filters(4).b = [];
prop.filters(4).a = [];
prop.filters(5).name = 'AC-coupled LFP';
prop.filters(5).abbreviation = 'AC';
prop.filters(5).b = [0.999989947009599  -0.999989947009599];
prop.filters(5).a = [1.000000000000000  -0.999979894019197];

sigNames = cell(1,65);
for ndx = 1:64
    sigNames{ndx} = [num2str(fix((ndx-1)/4)+1) char(mod(ndx-1,4)+65)];
end
sigNames{65} = 'SYNC';
prop.signalNames = sigNames;

col = hsv2rgb([linspace(0,1,9)' ones(9,2)]);
col = col(1:end-1,:);
col = col([1 5 2 6 3 7 4 8],:);
col(7,:) = [.7 .7 .7];
col(end+1,:) = [.4 .4 .4];
prop.colors = col;


prop.configurations(1).name = 'Spikes and SYNC';
prop.configurations(1).headerChannels = '65';
prop.configurations(1).footerChannels = '[]';
prop.configurations(1).browsableChannels = 'mat2cell(1:64,1,4*ones(1,16))';
prop.configurations(1).signalSources = '1:65';
prop.configurations(1).sourceIndices = 'ones(1,65)';
prop.configurations(1).filterGroups = '[2*ones(1,64) 1]';
prop.configurations(1).filters = '[4 2]';
prop.configurations(1).colorGroups = '[reshape(repmat(1:8,4,1),1,32)  reshape(repmat(1:8,4,1),1,32) 9]';
prop.configurations(1).colors = '1:9';
prop.configurations(1).yScales = 'ones(1,65)';
prop.configurations(1).yOffsets = 'zeros(1,65)';


prop.configurations(2).name = 'Combo';
prop.configurations(2).headerChannels = '[]';
prop.configurations(2).footerChannels = '[]';
prop.configurations(2).browsableChannels = 'mat2cell(1:64,1,4*ones(1,16))';
sig = [1 1 1 2; 2 2 2 3; 3 3 3 4; 4 4 4 1];
allsig = [];
for ndx = 1:16
    allsig = [allsig sig+4*(ndx-1)]; %#ok<AGROW>
end
prop.configurations(2).signalSources = allsig;
prop.configurations(2).sourceIndices = 'ones(1,64)';
prop.configurations(2).filterGroups = 'reshape(repmat([1 2 3 3]'',1,16),1,64)';
prop.configurations(2).filters = '[5 3 2]';
prop.configurations(2).colorGroups = '[reshape(repmat(1:8,4,1),1,32) reshape(repmat(1:8,4,1),1,32)]';
prop.configurations(2).colors = '1:8';
prop.configurations(2).yScales = 'ones(1,64)';
prop.configurations(2).yOffsets = 'zeros(1,64)';

prop.configurations(3).name = 'Raw LFP';
prop.configurations(3).headerChannels = '[]';
prop.configurations(3).footerChannels = '[]';
prop.configurations(3).browsableChannels = 'mat2cell(1:64,1,4*ones(1,16))';
prop.configurations(3).signalSources = '1:64';
prop.configurations(3).sourceIndices = 'ones(1,64)';
prop.configurations(3).filterGroups = 'ones(1,64)';
prop.configurations(3).filters = '1';
prop.configurations(3).colorGroups = '[reshape(repmat(1:8,4,1),1,32) reshape(repmat(1:8,4,1),1,32)]';
prop.configurations(3).colors = '1:8';
prop.configurations(3).yScales = 'ones(1,64)';
prop.configurations(3).yOffsets = 'zeros(1,64)';



function cf = initializationInThisFile(cf)

cf.rawFs = 1e6;
cf.fs = 1e6/32;


function cf = runtimeInThisFile(cf)

% Obtain the current number of samples acquired by the DAQ
cf.signals = rand(2^9,65);
cf.numSamp = cf.numSamp + numel(cf.signals);

function cf = terminationInThisFile(cf)