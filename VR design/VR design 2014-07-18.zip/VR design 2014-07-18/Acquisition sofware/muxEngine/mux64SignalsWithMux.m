function exper = mux64SignalsWithMux

exper.defaultProperties = @defaultPropertiesInThisFile;
exper.initializationFunction = @initializationInThisFile;
exper.runtimeFunction = @runtimeInThisFile;
exper.terminationFunction = @terminationInThisFile;

function prop = defaultPropertiesInThisFile

prop.xScale = 1;
prop.rollingMode = false;
prop.darkStripWidth = 10;
prop.margin = 70;
prop.showGridHorizontal = false;
prop.showGridVertical = true;
prop.channelsPerPage = 0;
prop.firstChannel = 1;
prop.triggerOn = false;
prop.triggerSource = 1;
prop.triggerThreshold = 1.9;
prop.triggerXPosition = 0.5;
prop.showThresholdDuration = 2;
prop.showTriggerDuration = 2;
prop.windowPosition = [100 100 400 600];
prop.currentConfiguration = 1;
prop.soundSource = 1;
prop.soundBuffering = 0.07;
prop.soundOn = false;

h  = fdesign.highpass('N,F3dB', 1, 500, 31250);
Hd = design(h, 'butter');
[b{1},a{1}] = sos2tf(Hd.sosMatrix,Hd.ScaleValues);
h  = fdesign.bandpass('N,F3dB1,F3dB2', 6, 80, 250, 31250);
Hd = design(h, 'butter');
[b{2},a{2}] = sos2tf(Hd.sosMatrix,Hd.ScaleValues);
for j = 1:length(b)
    for ndx = length(b{j}):-1:1
        if b{j}(ndx)==0 && a{j}(ndx)==0
            b{j}(ndx) = [];
            a{j}(ndx) = [];
        else
            break
        end
    end
end

prop.filters(1).name = 'Unfiltered LFP';
prop.filters(1).abbreviation = 'LFP';
prop.filters(1).b = [];
prop.filters(1).a = [];
prop.filters(2).name = 'Spikes (>500 Hz)';
prop.filters(2).abbreviation = 'SPK';
prop.filters(2).b = b{1};
prop.filters(2).a = a{1};
prop.filters(3).name = 'Ripples (800-250 Hz)';
prop.filters(3).abbreviation = 'RPL';
prop.filters(3).b = b{2};
prop.filters(3).a = a{2};
prop.filters(4).name = 'Unfiltered & unlabeled';
prop.filters(4).abbreviation = '';
prop.filters(4).b = [];
prop.filters(4).a = [];
prop.filters(5).name = 'AC-coupled LFP';
prop.filters(5).abbreviation = 'AC';
prop.filters(5).b = [0.999989947009599  -0.999989947009599];
prop.filters(5).a = [1.000000000000000  -0.999979894019197];

sigNames = cell(1,65);
for ndx = 1:64
    sigNames{ndx} = [num2str(fix((ndx-1)/4)+1) char(mod(ndx-1,4)+65)];
end
sigNames{65} = 'SYNC';
prop.signalNames = sigNames;

col = hsv2rgb([linspace(0,1,9)' ones(9,2)]);
col = col(1:end-1,:);
col = col([1 5 2 6 3 7 4 8],:);
col(7,:) = [.7 .7 .7];
col(end+1,:) = [.4 .4 .4];
prop.colors = col;


prop.configurations(1).name = 'Spikes and SYNC';
prop.configurations(1).headerChannels = '65';
prop.configurations(1).footerChannels = '[]';
prop.configurations(1).browsableChannels = 'mat2cell(1:64,1,4*ones(1,16))';
prop.configurations(1).signalSources = '1:65';
prop.configurations(1).sourceIndices = 'ones(1,65)';
prop.configurations(1).filterGroups = '[2*ones(1,64) 1]';
prop.configurations(1).filters = '[4 2]';
prop.configurations(1).colorGroups = '[reshape(repmat(1:8,4,1),1,32)  reshape(repmat(1:8,4,1),1,32) 9]';
prop.configurations(1).colors = '1:9';
prop.configurations(1).yScales = 'ones(1,65)';
prop.configurations(1).yOffsets = 'zeros(1,65)';


prop.configurations(2).name = 'Combo';
prop.configurations(2).headerChannels = '[]';
prop.configurations(2).footerChannels = '[]';
prop.configurations(2).browsableChannels = 'mat2cell(1:64,1,4*ones(1,16))';
sig = [1 1 1 2; 2 2 2 3; 3 3 3 4; 4 4 4 1];
allsig = [];
for ndx = 1:16
    allsig = [allsig sig+4*(ndx-1)]; %#ok<AGROW>
end
prop.configurations(2).signalSources = allsig;
prop.configurations(2).sourceIndices = 'ones(1,64)';
prop.configurations(2).filterGroups = 'reshape(repmat([1 2 3 3]'',1,16),1,64)';
prop.configurations(2).filters = '[5 3 2]';
prop.configurations(2).colorGroups = '[reshape(repmat(1:8,4,1),1,32) reshape(repmat(1:8,4,1),1,32)]';
prop.configurations(2).colors = '1:8';
prop.configurations(2).yScales = 'ones(1,64)';
prop.configurations(2).yOffsets = 'zeros(1,64)';

prop.configurations(3).name = 'Raw LFP';
prop.configurations(3).headerChannels = '[]';
prop.configurations(3).footerChannels = '[]';
prop.configurations(3).browsableChannels = 'mat2cell(1:64,1,4*ones(1,16))';
prop.configurations(3).signalSources = '1:64';
prop.configurations(3).sourceIndices = 'ones(1,64)';
prop.configurations(3).filterGroups = 'ones(1,64)';
prop.configurations(3).filters = '1';
prop.configurations(3).colorGroups = '[reshape(repmat(1:8,4,1),1,32) reshape(repmat(1:8,4,1),1,32)]';
prop.configurations(3).colors = '1:8';
prop.configurations(3).yScales = 'ones(1,64)';
prop.configurations(3).yOffsets = 'zeros(1,64)';



function cf = initializationInThisFile(cf)

% Defines a data output folder
cf.dataDir = [godesk '\muxlogs'];

% Get animal number from the user
answer = inputdlg({'Animal number'},'Animal number',1,{''});
if isempty(answer)
    answer = {'0'};
end
if ~exist([cf.dataDir '\' answer{1}],'dir')
    mkdir([cf.dataDir '\' answer{1}]);
end
cf.dataDir = [cf.dataDir '\' answer{1}];
cf.animalNum = answer{1};

% Load the animal's config file
try
    load([cf.dataDir '\..\config' cf.animalNum '.mat']);
    cf.p = prop;
catch %#ok<CTCH>
    cf.p.channelsPerUnit = 4;
end
if ~exist('logPos','var')
    logPos = [100 50 200 20];
end

% Define the number of headstages
cf.headstages = 2;

% Set up the DAQ
daqreset;
cf.ai = analoginput('nidaq','Dev1');
cf.ai.ClockSource = 'ExternalScanCtrl';
cf.ai.ExternalScanClockSource = 'PFI7';
cf.ai.LoggingMode = 'Disk';
nw = now;
cf.ai.LogFileName = [cf.dataDir '\' datestr(nw,'YYYYmmddTHHMMSS') '.daq'];
cf.ai.SamplesPerTrigger = inf;
cf.ai.SampleRate = 1e6;
cf.ai.BufferingConfig = [2^16 5];

% Add a channel for each headstage and define each channel's dynamic range
% Headstages are assumed to map like this:
% head1 (highest SYNC voltage) -> AI0, ...,
% head4 (lowest SYNC voltage) -> AI3
for ndx = 1:cf.headstages
    ch = addchannel(cf.ai,ndx-1);
    set(ch,'inputrange',[-2.5 2.5]);
end

% Add the SYNC channel (assumed to be plugged into AI4)
ch = addchannel(cf.ai,4);

% Define the dynanic range of the SYNC channel
set(ch,'inputrange',[-5 5]);

% Define error handling functions
cf.ai.DataMissedFcn = @dataMissed;
cf.ai.RuntimeErrorFcn = @runtimeError;

% Define other acquisition-related parameters
cf.buff = cf.ai.BufferingConfig;
cf.rawSignal = zeros(cf.buff(1),cf.headstages+1);
cf.rawFs = cf.ai.SampleRate;
cf.fs = cf.ai.SampleRate/32;

% Define the log file
cf.fid = fopen([cf.dataDir '\' datestr(nw,'YYYYmmddTHHMMSS') '.log'],'w');

% Define mux file
cf.muxFid = fopen([cf.dataDir '\' datestr(nw,'YYYYmmddTHHMMSS') '.mux'],'w');

% Start the DAQ
start(cf.ai);

% Initialize synchronization with ViRMEn (digital channels)
cf.dio = digitalio('nidaq','dev1');
addline(cf.dio,0:7,'in');

% Start a log GUI for typing in comments
logGui;
f = findall(0,'name','logGui');
set(f,'position',logPos);

% Write backup initialization time into the log file
fwrite(cf.fid,[-2 datenum(cf.ai.InitialTriggerTime) 0 length('BackupInitialTime') double('BackupInitialTime')],'double');

% Option to subtract channel
cf.referenceSubtract = 1;

function cf = runtimeInThisFile(cf)

% Obtain the current number of samples acquired by the DAQ
newSamp = cf.numSamp;
while newSamp == cf.numSamp
    newSamp = cf.ai.samplesAcquired;
end
cf.numSamp = newSamp;

% Obtain the latest data from the buffer
warning off daq:peekdata:requestedSamplesNotAvailable
try
    cf.rawSignal(:,:) = peekdata(cf.ai,cf.buff(1));
catch %#ok<CTCH>
    cf.rawSignal(:,:) = 0;
end

% Generate clicks (for debugging)
% cf.rawSignal = randn(size(cf.rawSignal))/100;
% cf.rawSignal(rand(size(cf.rawSignal))<.0005) = -0.1;

% Real-time demultiplexing
signal = round(cf.rawSignal(1:32,cf.headstages+1)/3.3*2^4-.5);
signal(signal<0) = 0;
signal = dec2bin(signal,4)-48;
out = ones(1,4);
f = cell(1,4);
for ndx = 1:4
    f{ndx} = find(signal(:,ndx)==1,1);
    if ~isempty(f{ndx})
        out(ndx) = f{ndx};
    end
end

% Write demux info to file
fwrite(cf.muxFid,cf.numSamp,'uint64');
fwrite(cf.muxFid,out,'uint8');

% Define order of wires from Intan to Neuralynx EIB
EIBOrder = [24:-1:17 1:16 32:-1:25];
for ndx = 1:cf.headstages
    lst = 32*(ndx-1)+1:32*ndx;
    cf.signals(:,lst) = reshape(cf.rawSignal(:,ndx),32,size(cf.rawSignal,1)/32)';
    cf.signals(:,lst(EIBOrder)) = cf.signals(:,lst([out(ndx):end 1:out(ndx)-1]));
end

% Define SYNC signal
for ndx = 1:4
    cf.signals((ndx-1)*size(cf.signals,1)/4+1:ndx*size(cf.signals,1)/4,65) = (~isempty(f{ndx}))*(5-ndx)/4;
end
cf.signals(1,65) = -0.5;
if length(cf.p.configurations(cf.p.currentConfiguration).yScales) == 65
    cf.signals(:,65) = cf.signals(:,65)*cf.p.configurations(cf.p.currentConfiguration).yScales(65)/100;
end

% If the user pressed Space, allow a comment to be typed in
if strcmp(cf.option,' ')
    fig = findall(0,'type','figure','name','logGui');
    figure(fig);
    uicontrol(findall(fig,'style','edit'));
end

% Reference subtraction
if strcmp(cf.option,'2')
    cf.referenceSubtract = cf.referenceSubtract-1;
    if cf.referenceSubtract == 0
        cf.referenceSubtract = 32;
    end
end
if strcmp(cf.option,'3')
    cf.referenceSubtract = cf.referenceSubtract+1;
    if cf.referenceSubtract == 33
        cf.referenceSubtract = 1;
    end
end
if strcmp(cf.option,'1')
    cf.referenceSubtract = -cf.referenceSubtract;
end
if cf.referenceSubtract > 0
    for ndx = 1:cf.headstages
        lst = 32*(ndx-1)+1:32*ndx;
        cf.signals(:,lst) = cf.signals(:,lst)-repmat(cf.signals(:,lst(cf.referenceSubtract)),1,32);
    end
end


% Obtain the number from ViRMEn (digital input) and write it to log file
iter = sum(getvalue(cf.dio).*[1 2 4 8 16 32 64 128]);
fwrite(cf.fid,[-1 now iter],'double');



function cf = terminationInThisFile(cf)

% Stop DAQ and close files
fclose(cf.fid);
fclose(cf.muxFid);
stop(cf.ai);
stop(cf.dio);

% Delete the comment GUI figure
f = findall(0,'name','logGui');
logPos = get(f,'position'); %#ok<NASGU>
set(f,'closerequestfcn','%');
delete(f);

% Update the config file
prop = cf.p; %#ok<NASGU>
save([cf.dataDir '\..\config' cf.animalNum '.mat'],'prop','logPos');

function dataMissed(~,evt)

global cf

fwrite(cf.fid,[-2 datenum(evt.Data.AbsTime) evt.Data.RelSample length('DataMissed') double('DataMissed')],'double'); % Data missed

function runtimeError(~,evt)

global cf

fwrite(cf.fid,[-2 datenum(evt.Data.AbsTime) evt.Data.RelSample length(evt.Data.String) double(evt.Data.String)],'double'); % Runtime error