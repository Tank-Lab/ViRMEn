#include "mex.h"

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) {
    double *out, *in, *b, *a, *y, *x;
    mwSize ord, sz, numchan;
    mwSize i, j, k;
     
    b = mxGetPr(prhs[0]);
    a = mxGetPr(prhs[1]);
    in = mxGetPr(prhs[2]);
    y = mxGetPr(prhs[3]);
    x = mxGetPr(prhs[4]);
    
    ord = mxGetM(prhs[3]);
    sz = mxGetM(prhs[2]);
    numchan = mxGetN(prhs[2]);
    
    plhs[0] = mxCreateDoubleMatrix(sz, numchan, mxREAL);
    out = mxGetPr(plhs[0]);
    
    for ( i = 0; i < sz; i++ ) {
        for ( j = 0; j < numchan; j++ ) {
            out[sz*j+i] = b[0]*in[sz*j+i];
            for (k = 0; k < ord; k++) {
                out[sz*j+i] = out[sz*j+i] + b[k+1]*x[ord*j+k];
            }
            for (k = 0; k < ord; k++) {
                out[sz*j+i] = out[sz*j+i] - a[k+1]*y[ord*j+k];
            }
            if ( a[0] != 1 ) {
                out[sz*j+i] = out[sz*j+i]/a[0];
            }
            for (k = ord; k > 1; k--) {
                x[ord*j+k-1] = x[ord*j+k-2];
                y[ord*j+k-1] = y[ord*j+k-2];
            }
            x[ord*j] = in[sz*j+i];
            y[ord*j] = out[sz*j+i];
        }
    }

    return;
}