function sout = convertStringStruct(s,varargin)

if nargin == 2 && iscell(varargin{1})
    varargin = varargin{1};
end

sout = struct;
fld = fieldnames(s);
for j = 1:length(s)
    for ndx = 1:length(fld)
        if isstruct(s(j).(fld{ndx}))
            sout(j).(fld{ndx}) = convertStringStruct(s(j).(fld{ndx}),varargin);
        elseif ischar(s(j).(fld{ndx}))
            isok = false;
            for v = 1:length(varargin)
                if strcmp(fld{ndx},varargin{v})
                    isok = true;
                end
            end
            if isok
                sout(j).(fld{ndx}) = s(j).(fld{ndx});
            else
                sout(j).(fld{ndx}) = eval(s(j).(fld{ndx}));
            end
        else
            sout(j).(fld{ndx}) = s(j).(fld{ndx});
        end
    end
end