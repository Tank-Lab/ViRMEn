function fold = godesk

lic = license('inuse');
fold = ['C:\Users\' lic(1).user '\Desktop'];