function varargout = logGui(varargin)

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @logGui_OpeningFcn, ...
                   'gui_OutputFcn',  @logGui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before logGui is made visible.
function logGui_OpeningFcn(hObject, eventdata, handles, varargin) %#ok<*INUSL>

set(handles.edit_log,'string','');
set(handles.list_log,'string',{'COMMENTS'});

handles.filePos = NaN;

% Update handles structure
guidata(hObject, handles);

% --- Outputs from this function are returned to the command line.
function varargout = logGui_OutputFcn(hObject, eventdata, handles)  %#ok<*STOUT>


% --- Executes on selection change in list_log.
function list_log_Callback(hObject, eventdata, handles) %#ok<*DEFNU,*INUSD>

global cf

strl = get(handles.list_log,'string');
indx = get(handles.list_log,'value');
if indx == 1
    cf.window.Activate;
    return
end

answer = inputdlg({'Change comment'},'Comment',1,{strl{indx}(10:end)});
if isempty(answer)
    cf.window.Activate;
    return
end
if isempty(answer{1})
    strl(indx) = [];
    handles.filePos(indx) = [];
else
    strl{indx} = [datestr(handles.filePos(indx),'HH:MM:SS') ' ' answer{1}];
end
set(handles.list_log,'value',1);
set(handles.list_log,'string',strl);

fwrite(cf.fid,[length(answer{1}) handles.filePos(indx) double(answer{1})],'double');

cf.window.Activate;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function list_log_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function close_Callback(hObject, eventdata, handles)



function edit_log_Callback(hObject, eventdata, handles)

global cf

str = get(handles.edit_log,'string');
if isempty(str)
    cf.window.Activate;
    return
end

fwrite(cf.fid,[length(str) now double(str)],'double');

nw = now;

strl = get(handles.list_log,'string');
strl{end+1} = [datestr(nw,'HH:MM:SS') ' ' str];
set(handles.list_log,'string',strl);
set(handles.edit_log,'string','');
handles.filePos(end+1) = nw;

cf.window.Activate;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit_log_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
