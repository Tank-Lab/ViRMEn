#include "mex.h"

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) {
    double *M, *xIndx, *yVal, *row, *yscale, *yposition, val;
    double minY, maxY, prc, x2, x1;
    mwSize numIndx, currX, prevX1, prevX2, indx, j, n, num;
       
    M = mxGetPr(prhs[0]);
    xIndx = mxGetPr(prhs[1]);
    yVal = mxGetPr(prhs[2]);
    row = mxGetPr(prhs[3]);
    yscale = mxGetPr(prhs[4]);
    yposition = mxGetPr(prhs[5]);
    
    numIndx = mxGetN(prhs[1]);
    num = mxGetM(prhs[0]);
    num = num*0.25;
    n = row[0]-1;
    
    for ( indx = 0; indx < numIndx; indx++ ) {
        val = yscale[0]*yVal[indx]+yposition[0];
        if ( indx == 0 ) {
            currX = xIndx[0];
            prevX1 = xIndx[0];
            prevX2 = xIndx[0];
            minY = val;
            maxY = val;
        }
        if ( xIndx[indx] != currX) {
            M[4*num*(currX-1)+4*n+1] = minY;
            M[4*num*(currX-1)+4*n+3] = maxY;
            prevX2 = prevX1;
            prevX1 = currX;
            currX = xIndx[indx];
            x1 = prevX1;
            x2 = prevX2;
            for (j = prevX2+1; j < prevX1; j++) {
                prc = (j-x2)/(x1-x2);
                M[4*num*(j-1)+4*n+1] = M[4*num*(prevX1-1)+4*n+1]*prc+M[4*num*(prevX2-1)+4*n+1]*(1-prc);
                M[4*num*(j-1)+4*n+3] = M[4*num*(prevX1-1)+4*n+3]*prc+M[4*num*(prevX2-1)+4*n+3]*(1-prc);
            }
            minY = val;
            maxY = val;
        }
        if ( val < minY ) {
            minY = val;
        }
        if ( val > maxY ) {
            maxY = val;
        }
    }
    
    if ( indx > 0 ) {
        M[4*num*(currX-1)+4*n+1] = minY;
        M[4*num*(currX-1)+4*n+3] = maxY;
        prevX2 = prevX1;
        prevX1 = currX;
        currX = xIndx[indx];
        x1 = prevX1;
        x2 = prevX2;
        for (j = prevX2+1; j < prevX1; j++) {
            prc = (j-x2)/(x1-x2);
            M[4*num*(j-1)+4*n+1] = M[4*num*(prevX1-1)+4*n+1]*prc+M[4*num*(prevX2-1)+4*n+1]*(1-prc);
            M[4*num*(j-1)+4*n+3] = M[4*num*(prevX1-1)+4*n+3]*prc+M[4*num*(prevX2-1)+4*n+3]*(1-prc);
        }
    }

    return;
}