#include "mex.h"

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) {
    double *demux, *sig, *sync, *Vmax, *syncBits, *numChan;
    double thres;
    mwSize totalPoints, pointsPerChan, numBits, maxBits;
    mwSize i, j, k, chanIndx, currSync, currPoint, currentLoc, phase;
     
    sig = mxGetPr(prhs[0]);
    sync = mxGetPr(prhs[1]);
    numChan = mxGetPr(prhs[2]);
    Vmax = mxGetPr(prhs[3]);
    thres = Vmax[0];
    syncBits = mxGetPr(prhs[4]);
    
    totalPoints = mxGetM(prhs[0]);
    numBits = mxGetN(prhs[4]);
    pointsPerChan = totalPoints/numChan[0];
    
    plhs[0] = mxCreateDoubleMatrix(pointsPerChan, numChan[0]*numBits, mxREAL);
    demux = mxGetPr(plhs[0]);
    
    maxBits = 0;
    for (i = 0; i < numBits; i++) {
        if (syncBits[i] > maxBits) {
            maxBits = syncBits[i];
        }
    }
    
    for (i = 0; i < maxBits; i++) {
        thres = thres/2;
        
        currSync = -1;
        for (j = 0; j < numBits; j++) {
            if (syncBits[j] == i+1) {
                currSync = j;
            }
        }

        phase = 0;
        for (currPoint = 0; currPoint < pointsPerChan; currPoint++) {            
            currentLoc = currPoint*numChan[0];
            if (sync[currentLoc+phase] < thres) { // Need to recalculate phase
                for (k = 0; k < numChan[0]; k++) {
                    if (sync[currentLoc+k] >= thres) {
                        phase = k;
                    }
                }
            }

            if (currSync > -1) {
                for (k = 0; k < numChan[0]; k++) {
                    chanIndx = k-phase;
                    if (chanIndx < 0) {
                        chanIndx = numChan[0]+chanIndx;
                    }
                    demux[currSync*totalPoints+chanIndx*pointsPerChan+currPoint] = sig[currSync*totalPoints+currentLoc+k];
                }
            }
            
            sync[currentLoc+phase] = sync[currentLoc+phase]-thres;;
        }
    }
    
//             mexPrintf("\n%d",maxBits);

    return;
}