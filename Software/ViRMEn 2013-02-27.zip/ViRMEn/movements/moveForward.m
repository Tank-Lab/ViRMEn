function velocity = moveForward(vr) %#ok<INUSD>

velocity = [0 0 0 0];